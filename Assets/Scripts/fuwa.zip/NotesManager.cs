using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NotesManager : MonoBehaviour
{
    public float speed = 6.0f; //物体の速度
    public Rigidbody2D rb2d;
    private Vector2 InitialDirection = new Vector2(1, 3).normalized; //正規化された物体の速度ベクトル
 
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        rb2d.velocity = speed * InitialDirection;
    }

    // Update is called once per frame
    void Update()
    {
        if (speed != 0)
        {
            Vector2 CurrentVelocity = rb2d.velocity;
            rb2d.velocity = CurrentVelocity.normalized * speed;
        }

        
    }

    
}
