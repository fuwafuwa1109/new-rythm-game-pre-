using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CircleManager : MonoBehaviour
{
    float timing = 0; //輪っかが押されるべきタイミング
    float ShrinkTime = 1f; //輪っかが縮むスピード
    float NowTime = 0; //輪っかが作られてからの時間
    [SerializeField] private GameObject Note;
    GameObject TrackObject;



    void Start()
    {
        transform.localScale = new Vector3(6f, 6f, 1);
        
    }

    void Update()
    {
        if (TrackObject != null)
        {
            transform.position = TrackObject.transform.position; // TrackObjectと同じ座標にする
        }
        NowTime += Time.deltaTime;
        ShrinkCircle();
    }

    

    public void SetTrackButton(GameObject Note)
    {
        TrackObject = Note;
    }

    void ShrinkCircle()
    {
        Vector3 CircleScale = transform.localScale; //輪っかを時間経過で縮ませる
        CircleScale.x = 6.5f - 4f * NowTime / ShrinkTime;
        CircleScale.y = 6.5f - 4f * NowTime / ShrinkTime;
        transform.localScale = CircleScale;
        if (CircleScale.x < 1.5) //輪っかが小さくなったらdestroy
        {
            Destroy(gameObject);
        }

    }
}
