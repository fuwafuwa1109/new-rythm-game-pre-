using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using System;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    [SerializeField] private GameObject[] Buttons; // タップやフリックの対象となるボタン
    [SerializeField] private GameObject Circle; // タップ用のノートオブジェクト
    [SerializeField] private GameObject Long; // ロングノート用のノートオブジェクト
    [SerializeField] private GameObject Flick; // フリック用のノートオブジェクト
    [SerializeField] private Text ComboText; // コンボ数を表示するテキスト
    public string CSVFileName; // 読み込むCSVファイルの名前

    private List<float>[] TimingLists = new List<float>[2]; // 各ボタンに対応するタイミングリスト
    private List<float> TimingList_all = new List<float>(); // 各ボタンに対応するタイミングリスト
    private List<int> WhichButton = new List<int>(); // どのボタンに対応するかを格納するリスト
    private List<string> NoteType = new List<string>(); // ノートの種類（タップ、フリック、ロング）を格納するリスト
    private List<GameObject>[] Notes = new List<GameObject>[2]; // 各ボタンに対応するノートのリスト

    int CSVIndex = 0; // 現在処理中のCSVのインデックス
    int[] Indexes = new int[2]; // 各ボタンのノートのインデックス
    int Combo = 0; // 現在のコンボ数

    public static float gametime; // ゲーム内の現在の時間
    float flickdistancemin = 0.01f; // フリックの最低移動距離
    float flicktimemax = 0.3f; // フリックの最大許容時間

    string gamestat = "playing"; // ゲームの状態（スタート、プレイ中など）

    bool[] isProcessing = new bool[2] { true, true }; // 各ボタンがタッチされているかどうか

    NotesManager[] notesManager = new NotesManager[2]; // 各ボタンに対応するノートマネージャー

    [SerializeField] private AudioSource audioSource; // ゲーム内の音声再生用
    [SerializeField] private AudioClip audioClip; // 再生するオーディオクリップ
    [SerializeField] private AudioSource tap;

    private void Start()
    {
        Debug.Log("Game Start");
        

        // 各ボタンに対応するノートリストを初期化
        for (int i = 0; i < Buttons.Length; i++)
        {
            Notes[i] = new List<GameObject>();
            TimingLists[i] = new List<float>(); // 各ボタンに対応するタイミングリストを初期化
            Indexes[i] = 0; // インデックスを0で初期化
        }
        TimingList_all = new List<float>();

        // 各ボタンに対応するNotesManagerを追加
        notesManager[0] = Buttons[0].AddComponent<NotesManager>();
        notesManager[1] = Buttons[1].AddComponent<NotesManager>();

        // CSVファイルを読み込み、音楽の再生を開始する
        ReadCSV(CSVFileName);
        audioSource = gameObject.AddComponent<AudioSource>();
        tap = gameObject.AddComponent<AudioSource>();
        audioSource.clip = audioClip;
        audioSource.Play();
    }

    private void Update()
    {
        // ゲームの状態による処理の分岐
        switch (gamestat)
        {
            case "start":
                // 音楽が再生されたらゲームを開始する
                if (audioSource.isPlaying)
                {
                    gamestat = "playing";
                }
                break;

            case "playing":
                // ゲームの時間を更新
                gametime = (float)audioSource.timeSamples / audioSource.clip.frequency;

                // ノートのスポーンタイミングかどうかをチェック
                for (int i = 0; i < 2; i++)
                {
                    if (CSVIndex < TimingList_all.Count && gametime > TimingList_all[CSVIndex] - 1)
                    {
                        // ノートを生成する
                        GenerateNote();
                    }
                }

                // タッチが行われたときの処理
                if (Input.touchCount > 0)
                {
                    for (int i = 0; i < Input.touchCount; i++)
                    {
                        Touch touch = Input.GetTouch(i);
                        HandleTouch(touch);

                    }
                }

                // ノートの有効範囲をチェックし、範囲外ならコンボをリセット
                CheckCircleSize();
                break;
        }
    }

    private void GenerateNote()
    {
        GameObject noteObject = null;

        // ノートの種類に応じてオブジェクトを生成
        if (NoteType[CSVIndex] == "tap")
        {
            noteObject = Instantiate(Circle, Buttons[WhichButton[CSVIndex]].transform.position, Quaternion.identity);
        }
        else if (NoteType[CSVIndex] == "flick")
        {
            noteObject = Instantiate(Flick, Buttons[WhichButton[CSVIndex]].transform.position, Quaternion.identity);
        }
        else if (NoteType[CSVIndex] == "longstart" || NoteType[CSVIndex] == "longfinish")
        {
            noteObject = Instantiate(Long, Buttons[WhichButton[CSVIndex]].transform.position, Quaternion.identity);
        }

        // 生成したノートオブジェクトをリストに追加し、ボタンに紐づける
        if (noteObject != null)
        {
            Notes[WhichButton[CSVIndex]].Add(noteObject);
            CircleManager circle = noteObject.GetComponent<CircleManager>();
            circle.SetTrackButton(Buttons[WhichButton[CSVIndex]]);
        }

        // CSVのインデックスを増やす""+
        CSVIndex++;
    }

    private void HandleTouch(Touch touch)
    {
        Vector2 touchPosition = Camera.main.ScreenToWorldPoint(touch.position);
        RaycastHit2D hit = Physics2D.Raycast(touchPosition, Vector2.zero);

        for (int j = 0; j < Buttons.Length; j++)
        {
            Vector2 Buttontransform = new Vector2(Buttons[j].transform.position.x, Buttons[j].transform.position.y);

            if (hit.collider != null)
            {
                if (hit.collider.gameObject == Buttons[j] && isProcessing[j])
                {
                    if (Indexes[j] <= Notes[j].Count)
                    {
                        isProcessing[j] = false;
                        StartCoroutine(NoteTap(touch, j));
                    }
                    else
                    {
                        Debug.LogWarning($"Before Destroy: Index {Indexes[j]}, Notes Count {Notes[j].Count}");
                    }
                }
            }
        }

    }



    IEnumerator NoteTap(Touch touch, int buttonIndex)
    {
        // ノートのインデックスが範囲外の場合、処理を終了
        if (Indexes[buttonIndex] > Notes[buttonIndex].Count)
        {
            //Debug.LogWarning("NoteTap: Index out of range for button " + buttonIndex);
            yield break;
        }

        string notetype = NoteType[Indexes[buttonIndex]];
        float starttime = gametime;
        Vector2 startpos = touch.position;


        switch (notetype)
        {
            case "tap":
                // タップ判定
                CheckTiming(Indexes[buttonIndex], gametime, buttonIndex);
                isProcessing[buttonIndex] = true;
                tap.Play();
                break;

            case "flick":
                // フリック判定
                while (true)
                {
                    // タッチ情報を更新
                    if (Input.touchCount > 0)
                    {
                        touch = Input.GetTouch(0); // もしくは、適切なタッチインデックスを再取得
                        if (touch.phase == TouchPhase.Ended)
                        {
                            break; // TouchPhase.Ended を検知したらループを抜ける
                        }
                    }
                    yield return null; // 毎フレーム待機
                }
                Vector2 moveVector = touch.position - startpos;
                if (gametime - starttime < flicktimemax && moveVector.magnitude > flickdistancemin)
                {
                    isProcessing[buttonIndex] = true;
                    CheckTiming(Indexes[buttonIndex], gametime, buttonIndex);
                }
                break;

            case "longstart":
                // ロングノートの開始判定
                CheckTiming(Indexes[buttonIndex], gametime, buttonIndex);

                Vector2 currentVector = notesManager[buttonIndex].rb2d.velocity;
                notesManager[buttonIndex].rb2d.velocity = Vector2.zero;
                


                // タッチが終了するまで待機
                while (true)
                {
                    // タッチ情報を更新
                    if (Input.touchCount > 0)
                    {
                        touch = Input.GetTouch(0); // もしくは、適切なタッチインデックスを再取得
                        notesManager[buttonIndex].rb2d.velocity = Vector2.zero;

                        if (touch.phase == TouchPhase.Ended)
                        {
                            break; // TouchPhase.Ended を検知したらループを抜ける
                        }
                    }
                    yield return null; // 毎フレーム待機
                }
                notesManager[buttonIndex].rb2d.velocity = currentVector;

                // ロングノートの終了判定を行い、指が離された後の処理
                isProcessing[buttonIndex] = true;
                CheckTiming(Indexes[buttonIndex], gametime, buttonIndex);
                break;

            

            
        }
    }

    private void CheckTiming(int index, float timing, int buttonIndex)
    {
        if (index < Notes[buttonIndex].Count && Notes[buttonIndex][index] != null)
        {
            GameObject note = Notes[buttonIndex][index];
            //Debug.Log($"Before Destroy: Index {index}, Notes Count {Notes[buttonIndex].Count}");
            Destroy(note);
            Combo++;
            ComboText.text = Combo.ToString();
            Indexes[buttonIndex]++;
        }
        else
        {
            Combo = 0;
            ComboText.text = Combo.ToString();
        }
    }

    void ReadCSV(string csvFileName)
    {
        // CSVファイルのパスを取得
        string filePath = Path.Combine(Application.streamingAssetsPath, csvFileName);
        if (File.Exists(filePath))
        {
            // CSVファイルを読み込み、タイミングリスト、ボタン、ノートタイプを設定
            string[] csvLines = File.ReadAllLines(filePath);

            foreach (string line in csvLines)
            {
                string[] rowData = line.Split(',');
                int buttonIndex = rowData[0] == "button1" ? 0 : 1;

                TimingLists[buttonIndex].Add(Convert.ToSingle(rowData[1])); // ボタンに対応するタイミングリストに追加
                TimingList_all.Add(Convert.ToSingle(rowData[1]));
                WhichButton.Add(buttonIndex);
                NoteType.Add(rowData[2]);
            }
        }
        else
        {
            Debug.LogError("CSV file not found at " + filePath);
        }
    }

    private void CheckCircleSize()
    {
        for (int i = 0; i < 2; i++)
        {
            // Notes[i]が空でないか確認し、インデックスが範囲内であるかチェック
            if (Indexes[i] < Notes[i].Count && Notes[i] != null)
            {
                if (gametime > TimingLists[i][Indexes[i]] + 0.8f)
                {
                    //Debug.Log($"Before Destroy: Index {Indexes[i]}, Notes Count {Notes[i].Count}");
                    Indexes[i]++;



                    Combo = 0;
                    ComboText.text = Combo.ToString();
                }
            }
            
        }
    }

    



}
